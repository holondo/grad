#ifndef MERGE_H

    #define MERGE_H
    #include "hash.h"
    
    login padroniza(login pAtual);
    void merge(login *v, int ini, int centro, int fim);
    void mergesort (login *v, int ini, int fim);
    
    
#endif
